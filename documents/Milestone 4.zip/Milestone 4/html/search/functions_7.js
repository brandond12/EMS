var searchData=
[
  ['log',['Log',['../class_supporting_1_1_logging.html#a60b0734ed288df6dc8af94f8fe4a0143',1,'Supporting::Logging']]]
];
