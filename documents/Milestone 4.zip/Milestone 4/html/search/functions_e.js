var searchData=
[
  ['uimenu',['UIMenu',['../class_presentation_1_1_u_i_menu.html#aecce7fd9ed4696929cbcada2da8c4c2c',1,'Presentation.UIMenu.UIMenu()'],['../class_presentation_1_1_u_i_menu.html#ac27724c06cbdcddbcf940f812ba307e3',1,'Presentation.UIMenu.UIMenu(Container repo)']]]
];
