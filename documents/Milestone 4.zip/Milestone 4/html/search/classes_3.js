var searchData=
[
  ['logging',['Logging',['../class_supporting_1_1_logging.html',1,'Supporting']]]
];
